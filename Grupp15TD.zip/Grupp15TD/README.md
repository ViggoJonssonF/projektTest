# projekt test
## 2 olika ekonomier
## emotes
## mer fiender 
## mer defense
## multiplayer
## bättre UI
## bättre map
## meny (val av lag innan match (blå och röd), välja karakätrer/torn för båda lagen, rematch knapp)
## rounds
## upgrades för defense
## ta bort darts/projectiles då de träffar enemies
## spendera ekonomi för att skicka enemies på motståndare
## dynamisk ekonomi som påverkas av vad man skickar (kan öka eller minska beroende på vad man skickar)
## få info om karaktärer/torn om man klickar på dem
## animations för sprites (sprite sheets)
## "drag and drop" för torn med synlig range cirkel vid placering
## ljudeffekter 