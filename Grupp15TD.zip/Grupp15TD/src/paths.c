#include "paths.h"
#include "defs.h" 
#include "engine.h"

// Creates the hardcoded path coordinates based on window dimensions
Paths createPaths(void) {
    Paths p;
    p.nmbrOfPoints = NUM_POINTS;

    // Using WINDOW_WIDTH/HEIGHT constants from defs.h
    p.points.left[0]  = (SDL_Point){ (int)(WINDOW_WIDTH / 4.615), 0 };                     // Approx 260
    p.points.left[1]  = (SDL_Point){ (int)(WINDOW_WIDTH / 4.615), (int)(WINDOW_HEIGHT * 0.09) }; // 260, 54
    p.points.left[2]  = (SDL_Point){ (int)(WINDOW_WIDTH / 10.67), (int)(WINDOW_HEIGHT * 0.09) }; // 112, 54
    p.points.left[3]  = (SDL_Point){ (int)(WINDOW_WIDTH / 10.67), (int)(WINDOW_HEIGHT * 0.20) }; // 112, 120
    p.points.left[4]  = (SDL_Point){ (int)(WINDOW_WIDTH / 6.857), (int)(WINDOW_HEIGHT * 0.20) }; // 175, 120
    p.points.left[5]  = (SDL_Point){ (int)(WINDOW_WIDTH / 2.341), (int)(WINDOW_HEIGHT * 0.20) }; // 512, 120
    p.points.left[6]  = (SDL_Point){ (int)(WINDOW_WIDTH / 2.341), (int)(WINDOW_HEIGHT * 0.35) }; // 512, 210
    p.points.left[7]  = (SDL_Point){ (int)(WINDOW_WIDTH / 3.2),   (int)(WINDOW_HEIGHT * 0.35) }; // 375, 210
    p.points.left[8]  = (SDL_Point){ (int)(WINDOW_WIDTH / 3.2),   (int)(WINDOW_HEIGHT * 0.61) }; // 375, 366
    p.points.left[9]  = (SDL_Point){ (int)(WINDOW_WIDTH / 2.526), (int)(WINDOW_HEIGHT * 0.61) }; // 475, 366
    p.points.left[10] = (SDL_Point){ (int)(WINDOW_WIDTH / 2.526), (int)(WINDOW_HEIGHT * 0.90) }; // 475, 540
    p.points.left[11] = (SDL_Point){ (int)(WINDOW_WIDTH / 13.714),(int)(WINDOW_HEIGHT * 0.90) }; // 87, 540
    p.points.left[12] = (SDL_Point){ (int)(WINDOW_WIDTH / 13.714),(int)(WINDOW_HEIGHT * 0.65) }; // 87, 390
    p.points.left[13] = (SDL_Point){ (int)(WINDOW_WIDTH / 4.364), (int)(WINDOW_HEIGHT * 0.65) }; // 275, 390
    p.points.left[14] = (SDL_Point){ (int)(WINDOW_WIDTH / 4.364), WINDOW_HEIGHT };             // 275, 600

    // Right Path 
    p.points.right[0]  = (SDL_Point){ WINDOW_WIDTH - (int)(WINDOW_WIDTH / 4.615), 0 };                     // Approx 940
    p.points.right[1]  = (SDL_Point){ WINDOW_WIDTH - (int)(WINDOW_WIDTH / 4.615), (int)(WINDOW_HEIGHT * 0.09) }; // 940, 54
    p.points.right[2]  = (SDL_Point){ WINDOW_WIDTH - (int)(WINDOW_WIDTH / 10.67), (int)(WINDOW_HEIGHT * 0.09) }; // 1088, 54
    p.points.right[3]  = (SDL_Point){ WINDOW_WIDTH - (int)(WINDOW_WIDTH / 10.67), (int)(WINDOW_HEIGHT * 0.20) }; // 1088, 120
    p.points.right[4]  = (SDL_Point){ WINDOW_WIDTH - (int)(WINDOW_WIDTH / 6.857), (int)(WINDOW_HEIGHT * 0.20) }; // 1025, 120
    p.points.right[5]  = (SDL_Point){ WINDOW_WIDTH - (int)(WINDOW_WIDTH / 2.341), (int)(WINDOW_HEIGHT * 0.20) }; // 688, 120
    p.points.right[6]  = (SDL_Point){ WINDOW_WIDTH - (int)(WINDOW_WIDTH / 2.341), (int)(WINDOW_HEIGHT * 0.35) }; // 688, 210
    p.points.right[7]  = (SDL_Point){ WINDOW_WIDTH - (int)(WINDOW_WIDTH / 3.2),   (int)(WINDOW_HEIGHT * 0.35) }; // 825, 210
    p.points.right[8]  = (SDL_Point){ WINDOW_WIDTH - (int)(WINDOW_WIDTH / 3.2),   (int)(WINDOW_HEIGHT * 0.61) }; // 825, 366
    p.points.right[9]  = (SDL_Point){ WINDOW_WIDTH - (int)(WINDOW_WIDTH / 2.526), (int)(WINDOW_HEIGHT * 0.61) }; // 725, 366
    p.points.right[10] = (SDL_Point){ WINDOW_WIDTH - (int)(WINDOW_WIDTH / 2.526), (int)(WINDOW_HEIGHT * 0.90) }; // 725, 540
    p.points.right[11] = (SDL_Point){ WINDOW_WIDTH - (int)(WINDOW_WIDTH / 13.714),(int)(WINDOW_HEIGHT * 0.90) }; // 1113, 540
    p.points.right[12] = (SDL_Point){ WINDOW_WIDTH - (int)(WINDOW_WIDTH / 13.714),(int)(WINDOW_HEIGHT * 0.65) }; // 1113, 390
    p.points.right[13] = (SDL_Point){ WINDOW_WIDTH - (int)(WINDOW_WIDTH / 4.364), (int)(WINDOW_HEIGHT * 0.65) }; // 925, 390
    p.points.right[14] = (SDL_Point){ WINDOW_WIDTH - (int)(WINDOW_WIDTH / 4.364), WINDOW_HEIGHT };             // 925, 600

    return p;
}
