#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <time.h>

#include <SDL2/SDL.h>
#include <SDL2/SDL_net.h>
#include <SDL2/SDL_ttf.h>

#include "engine.h"
#include "paths.h"

// --- Static Function Prototypes ---
static bool initialize_server(ServerInstance* server);
static void run_server_loop(ServerInstance* server);
static void shutdown_server(ServerInstance* server);
static void handle_client_packet(ServerInstance* server, UDPpacket* packet);
static int find_client_index(ServerInstance* server, IPaddress address);
static int add_client(ServerInstance* server, IPaddress address);
static void broadcast_packet(ServerInstance* server, ServerPacketData* data);
// Revert to using send_packet_to_client for replies for simplicity/reliability check
static void send_packet_to_client(ServerInstance* server, int clientIndex, ServerPacketData* data);
// static bool send_minimal_packet_to_client(ServerInstance* server, int clientIndex, ServerCommandType command); // Removed
static void prepare_snapshot(GameState* current_state, GameStateSnapshot* snapshot);
static void update_server_game_state(ServerInstance* server, float dt);
static void render_debug_view(ServerInstance* server);


// --- Public Entry Point ---
int run_server(void) {

    ServerInstance server = {0};
    srand((unsigned int)time(NULL));
    server.is_running = true;
    //SDL initialization
    if (SDL_Init(SDL_INIT_TIMER | SDL_INIT_VIDEO | SDL_INIT_AUDIO) != 0) {
        printf("SDL_Init Error: %s\n", SDL_GetError());
        return 1;
    }
    if (!initialize_subsystems()) {
        printf("Failed to initialize SDL subsystems.\n");
        SDL_Quit(); return 1;
    }
    if (!initialize_sdl(&server.debugWindow, &server.debugRenderer, "Tower Defense Server")) {
        printf("Server SDL Window/Renderer Init failed.\n");
        cleanup_subsystems();
        SDL_Quit();
        return 1;
    }
    if (!load_resources(server.debugRenderer, &server.resources, &server.audio)) {
        printf("Server critical resource loading failed.\n");
        cleanup_sdl(server.debugWindow, server.debugRenderer);
        cleanup_subsystems();
        SDL_Quit();
        return 1;
    }

    GameStatus currentStatus = GAME_STATE_MAIN_MENU;
    printf("Server started. Displaying Main Menu.\n");
    //menyn ser fine ut
    while (server.is_running && currentStatus == GAME_STATE_MAIN_MENU) {
        SDL_Event event;
        while(SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) {
                server.is_running = false;
                break;
            }
            if (event.type == SDL_KEYDOWN) {
                if (event.key.keysym.sym == SDLK_SPACE) {
                    currentStatus = GAME_STATE_PLAYING;
                    printf("Space pressed, initializing network...\n");
                }
                else if (event.key.keysym.sym == SDLK_ESCAPE) {
                    server.is_running = false;
                    break;
                }
            }
        }
        SDL_SetRenderDrawColor(server.debugRenderer, 0, 0, 0, 255);
        SDL_RenderClear(server.debugRenderer);
        render_main_menu(server.debugRenderer, &server.resources, MODE_SERVER);
        SDL_Delay(10);//idk om den här behövs?
    }

    if (server.is_running) {//lite kladdigt men funkar
        if (!initialize_server(&server)) {
            printf("Server network/state initialization failed.\n");
            shutdown_server(&server);
            return 1;
        }
        run_server_loop(&server);
    }
    shutdown_server(&server);
    printf("Server shut down normally.\n");
    return 0;
}

// --- Initialization (Network and Game State part) ---
static bool initialize_server(ServerInstance* server) {
    //Gamestate init
    server->num_clients = 0;
    server->lastTickTime = SDL_GetTicks();
    initialize_game_state(&server->gameState, &server->resources);
    //Socket init
    printf("Opening UDP socket on port %d...\n", SERVER_PORT);
    server->socket = SDLNet_UDP_Open(SERVER_PORT);
    if (!server->socket) {
        printf("SDLNet_UDP_Open Error: %s\n", SDLNet_GetError());
        return false;
    }
    //Packet init
    server->packet_in = SDLNet_AllocPacket(PACKET_BUFFER_SIZE);
    server->packet_out = SDLNet_AllocPacket(PACKET_BUFFER_SIZE);
    if (!server->packet_in || !server->packet_out) {
        printf("SDLNet_AllocPacket Error: %s\n", SDLNet_GetError());
        if (server->packet_in) SDLNet_FreePacket(server->packet_in);
        if (server->packet_out) SDLNet_FreePacket(server->packet_out);
        if(server->socket) SDLNet_UDP_Close(server->socket);
        server->socket = NULL;
        return false;
    }

    printf("Server network initialized. Waiting for players...\n");
    return true;
}

// --- Main Server Game Loop ---
static void run_server_loop(ServerInstance* server) {
    bool game_started = false;
    Uint32 time_per_tick = 1000 / GAME_TICK_RATE;

    while (server->is_running) {

        //timing
        Uint32 currentTime = SDL_GetTicks();
        Uint32 elapsedTime = currentTime - server->lastTickTime;
        SDL_Event event;

        // quit handle, lägg kanske till en quit confirm?
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) server->is_running = false;
            if (event.type == SDL_KEYDOWN && event.key.keysym.sym == SDLK_ESCAPE) server->is_running = false;
        }
        if (!server->is_running) break;

        //Läs packets
        while (SDLNet_UDP_Recv(server->socket, server->packet_in) > 0) {
            handle_client_packet(server, server->packet_in);
        }

        if (elapsedTime >= time_per_tick) {//timing
            float dt = (float)elapsedTime / 1000.0f;
            if (dt > 0.1f) dt = 0.1f;
            server->lastTickTime = currentTime;

            if (!game_started) {
                bool allrdy = (server->num_clients == MAX_PLAYERS);//kladdig dubbelcheck
                if(allrdy) for(int i=0;i<server->num_clients;++i) if(!server->clients[i].ready) allrdy=false;
                if(allrdy) {
                    printf("All %d players ready! Starting game.\n", MAX_PLAYERS);
                    game_started = true;
                    server->gameState.spawnTimer = 0.0f;
                    server->gameState.moneyTimer = 0.0f;
                    ServerPacketData sp = {.command = SERVER_CMD_GAME_START};
                    broadcast_packet(server, &sp);
                } else {
                    static Uint32 lwb = 0;//wtf betyder lwb???
                    if(currentTime - lwb > 1000) {
                        ServerPacketData wp = {.command = SERVER_CMD_WAITING, .clientsConnected = server->num_clients};
                        broadcast_packet(server, &wp);
                        lwb = currentTime;//vad gör den här koden ens????
                    }
                }
            }

            if (game_started && !server->gameState.gameOver) {//game over check
                update_server_game_state(server, dt);
                if (server->gameState.gameOver) {
                    printf("Server detected Game Over. Winner: %d\n", server->gameState.winner);
                    ServerPacketData op = {.command = SERVER_CMD_GAME_OVER};
                    prepare_snapshot(&server->gameState, &op.snapshot);
                    broadcast_packet(server, &op);
                }
            }

            if (game_started) {//skicka update till klienter
                ServerPacketData stp = {.command = SERVER_CMD_STATE_UPDATE};
                prepare_snapshot(&server->gameState, &stp.snapshot);
                broadcast_packet(server, &stp);
            }
             render_debug_view(server);
        }
        Uint32 ft = SDL_GetTicks() - currentTime;
        if (ft < time_per_tick) SDL_Delay(time_per_tick - ft);
        else SDL_Delay(1);//consistent delay?
    }
}

// Wrapper function to call the split game logic updates including spawn timer
static void update_server_game_state(ServerInstance* server, float dt) {
    GameState* gs      = &server->gameState;
    GameResources* res = &server->resources;
    Audio* audio       = &server->audio;   

    handle_money_gain(gs, dt);

    if (gs->inWaveDelay) {
        gs->spawnCooldown -= dt;
        if (gs->spawnCooldown <= 0.0f) {
            gs->inWaveDelay = false;
            if (gs->currentWave > 0) {
                play_sound(audio, audio->levelUpSound);
            }
            gs->currentWave++;
            gs->spawnTimer   = ENEMY_SPAWN_INTERVAL;  // spawn direkt
        }
    }
    else {
        gs->spawnTimer += dt;
        if (gs->spawnTimer >= ENEMY_SPAWN_INTERVAL) {
            gs->spawnTimer -= ENEMY_SPAWN_INTERVAL;
            spawn_enemy_pair(gs, res);
        }
    }
    update_enemies(gs, dt);
    update_towers(gs, audio, dt, res);
    update_projectiles(gs, dt);
}


// --- Networking Helpers ---
static int find_client_index(ServerInstance* server, IPaddress address) {
    for (int i = 0; i < server->num_clients; ++i){//tror det här bör skrivas om med en continue; och en sats som returnerar -1 efteråt
        if (server->clients[i].address.host == address.host && server->clients[i].address.port == address.port)return i; //return -1;
    }
    return -1;
}

static int add_client(ServerInstance* server, IPaddress address) {
    if (server->num_clients >= MAX_PLAYERS) return -1;
    int ni = server->num_clients++;
    server->clients[ni].address = address;
    server->clients[ni].ready = false;
    server->clients[ni].lastPacketTime = SDL_GetTicks();
    return ni;
}

static void handle_client_packet(ServerInstance* server, UDPpacket* packet) {
    if ((size_t)packet->len < sizeof(ClientCommandType)) return;//kolla om packet är valid
    ClientPacketData cd;
    size_t cs = ((size_t)packet->len < sizeof(ClientPacketData)) ? (size_t)packet->len : sizeof(ClientPacketData);//client packet size
    memcpy(&cd, packet->data, cs);

    int ci = find_client_index(server, packet->address);//kolla om paketet tillhör en existerande klient
    if (ci == -1) {//Sektionen hanterar när klienterna connectar för första gången
        if (cd.command == CLIENT_CMD_READY) {
            int ni = add_client(server, packet->address);//Lägg till klient, -1 om listan är full
            if (ni != -1) {
                printf("Player %d connected: %x:%d\n", ni, packet->address.host, packet->address.port);
                ServerPacketData ap = {.command = SERVER_CMD_ASSIGN_INDEX, .assignedPlayerIndex = ni};//assignment Packet?
                send_packet_to_client(server, ni, &ap);/* Send full packet */
                server->clients[ni].ready = true;//sätter ready instantly när man connectar?
                printf("Player %d marked as ready.\n", ni);
                ServerPacketData wp = {.command = SERVER_CMD_WAITING, .clientsConnected = server->num_clients};
                broadcast_packet(server, &wp);//welcome packet???
            }
            else {
                printf("Connection rejected (Server Full) for %x:%d\n", packet->address.host, packet->address.port);
                ServerPacketData rp = {.command = SERVER_CMD_REJECT_FULL};//rejection packet?
                server->packet_out->address = packet->address;
                server->packet_out->len = sizeof(ServerCommandType);
                memcpy(server->packet_out->data, &rp, server->packet_out->len);
                SDLNet_UDP_Send(server->socket, -1, server->packet_out);
            }
        }
        return;
    }
    server->clients[ci].lastPacketTime = SDL_GetTicks();
    if (cd.playerIndex != ci && cd.command != CLIENT_CMD_READY) { /* Reduced verbosity */ }
    switch (cd.command) {//vi vet redan att cd.playerindex är samma som ci, varför kollar vi igen??
        case CLIENT_CMD_READY://varför kollar vi två gånger efter ready?
            if (!server->clients[ci].ready) {
                server->clients[ci].ready = true;
                printf("Player %d signaled ready.\n", ci);
                ServerPacketData wp = {.command = SERVER_CMD_WAITING, .clientsConnected = server->num_clients};
                broadcast_packet(server, &wp);
            }
            break;
        case CLIENT_CMD_PLACE_TOWER:
            if (server->gameState.gameOver) break;
            // Call place_tower which has internal prints
            bool placed = place_tower(&server->gameState, &server->resources, cd.towerTypeIndex, cd.targetX, cd.targetY, ci);
            // *** Send standard packet, but only populate the command field ***
            ServerPacketData reply = {0}; // Initialize all fields to 0/NULL/false
            reply.command = placed ? SERVER_CMD_PLACE_TOWER_CONFIRM : SERVER_CMD_PLACE_TOWER_REJECT;
            printf("Server: Sending reply (Cmd: %d) to P%d for placement.\n", reply.command, ci);
            send_packet_to_client(server, ci, &reply); // Use standard send function
            // *** End Change ***
            break;
        case CLIENT_CMD_HEARTBEAT: break;
        default: printf("Warn: Unknown cmd %d from client %d.\n", cd.command, ci);
            break;
    }
}
static void broadcast_packet(ServerInstance* server, ServerPacketData* data) {
    if (!server->packet_out) return;
    server->packet_out->len = sizeof(ServerPacketData);
    memcpy(server->packet_out->data, data, server->packet_out->len);
    for (int i = 0; i < server->num_clients; ++i) {
        server->packet_out->address = server->clients[i].address;
        if(SDLNet_UDP_Send(server->socket, -1, server->packet_out) == 0){
            printf("Warn: broadcast send failed to P%d\n", i);
        }
    }
} // Added send check

static void send_packet_to_client(ServerInstance* server, int ci, ServerPacketData* data) {
    if (ci < 0 || ci >= server->num_clients || !server->packet_out) return;
    server->packet_out->len = sizeof(ServerPacketData);
    memcpy(server->packet_out->data, data, server->packet_out->len);
    server->packet_out->address = server->clients[ci].address;
    if(SDLNet_UDP_Send(server->socket, -1, server->packet_out) == 0){
    printf("Warn: send_packet failed to P%d (Cmd %d)\n", ci, data ? data->command : -1);
    }
} // Added send check + cmd log

// Removed send_minimal_packet_to_client function

static void prepare_snapshot(GameState* cs, GameStateSnapshot* ss) {
    if (!cs || !ss) return;
    memset(ss, 0, sizeof(GameStateSnapshot));
    ss->money = cs->money;
    ss->leftPlayerHP = cs->leftPlayerHP;
    ss->rightPlayerHP = cs->rightPlayerHP;
    ss->currentWave = cs->currentWave;   
    ss->gameOver = cs->gameOver;
    ss->winner = cs->winner;
    ss->numEnemiesActive = cs->numEnemiesActive;
    for (int i = 0; i < cs->numEnemiesActive; ++i) {
        ss->enemies[i].x = cs->enemies[i].x;
        ss->enemies[i].y = cs->enemies[i].y;
        ss->enemies[i].angle = cs->enemies[i].angle;
        ss->enemies[i].type = cs->enemies[i].type;
        ss->enemies[i].hp = cs->enemies[i].hp;
        ss->enemies[i].active = cs->enemies[i].active;
        ss->enemies[i].side = cs->enemies[i].side;
    }
    ss->numPlacedBirds = cs->numPlacedBirds; /*printf("Prepare Snapshot: %d birds\n", cs->numPlacedBirds);*/
    for (int i = 0; i < cs->numPlacedBirds; ++i) {
        ss->placedBirds[i].x = cs->placedBirds[i].x;
        ss->placedBirds[i].y = cs->placedBirds[i].y;
        ss->placedBirds[i].typeIndex = cs->placedBirds[i].towerTypeIndex;
        ss->placedBirds[i].attackAnimTimer = cs->placedBirds[i].attackAnimTimer;
        ss->placedBirds[i].active = cs->placedBirds[i].active;
        ss->placedBirds[i].ownerPlayerIndex = cs->placedBirds[i].ownerPlayerIndex;
    }
    ss->numProjectiles = cs->numProjectiles;
    for (int i = 0; i < cs->numProjectiles; ++i) {
        ss->projectiles[i].x = cs->projectiles[i].x;
        ss->projectiles[i].y = cs->projectiles[i].y;
        ss->projectiles[i].angle = cs->projectiles[i].angle;
        ss->projectiles[i].projectileTextureIndex = cs->projectiles[i].textureIndex;
        ss->projectiles[i].active = cs->projectiles[i].active;
    }
}
static void shutdown_server(ServerInstance* server) {
    printf("Shutting down server...\n");
    if (!server) return;
    if (server->packet_in) SDLNet_FreePacket(server->packet_in);
    if (server->packet_out) SDLNet_FreePacket(server->packet_out);
    if (server->socket) SDLNet_UDP_Close(server->socket);
    server->packet_in = NULL;
    server->packet_out = NULL;
    server->socket = NULL;
    if (server->debugRenderer) {
        cleanup_resources(&server->resources, &server->audio);
    }
    cleanup_sdl(server->debugWindow, server->debugRenderer);
    cleanup_subsystems();
    SDL_QuitSubSystem(SDL_INIT_TIMER);
    SDL_Quit();
    printf("Server shutdown complete.\n");
}
static void render_debug_view(ServerInstance* server) {
    if (!server->debugRenderer || !server->resources.font) return;
    calculate_tower_rotations(&server->gameState, server->birdRotations);
    SDL_SetRenderDrawColor(server->debugRenderer, 0, 50, 0, 255);
    SDL_RenderClear(server->debugRenderer);
    render_game(server->debugRenderer, &server->gameState, &server->resources, server->birdRotations, false, -1, -1);
    char st[128];
    snprintf(st, sizeof(st), "Server - Clients: %d/%d Birds: %d Money: %d", server->num_clients, MAX_PLAYERS, server->gameState.numPlacedBirds, server->gameState.money);
    render_text(server->debugRenderer, server->resources.font, st, 10, 10, (SDL_Color){255,255,255,255}, false);
    SDL_RenderPresent(server->debugRenderer);
}