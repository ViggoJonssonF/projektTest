#include <stdio.h>
#include <SDL2/SDL.h>

#include "engine.h" // For run_client prototype

#ifdef CLIENT
int main(int argc, char *argv[]) {
    const char* server_ip = "127.0.0.1";
    if (argc > 1) { server_ip = argv[1]; }
    printf("Starting Tower Defense Client (Connecting to %s)...\n", server_ip);
    // Client init/cleanup handled within run_client()
    int result = run_client(server_ip);
    printf("Client process finished with exit code %d.\n", result);
    return result;
}
#endif // CLIENT
// Note: The client loop in client.c will pass MODE_CLIENT to render_main_menu.
