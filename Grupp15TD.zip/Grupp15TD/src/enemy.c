#include <math.h>
#include <stdio.h>
#include <stdlib.h> 
#include <string.h> 
#include <stdbool.h> 
#include "engine.h" 

float newCords(float a, float b, float t) {
    return a + (b - a) * t;
}

// Updates all active enemies: movement, reaching goal, HP loss check
void update_enemies(GameState *gameState, float dt) {
    if (!gameState || dt <= 0) return; 
    Paths* paths = &gameState->paths;

    for (int i = 0; i < gameState->numEnemiesActive;) {
        Enemy *enemy = &gameState->enemies[i];

        // If enemy became inactive (killed by tower or out of screen), compact the array
        if (!enemy->active) {
            if (i < gameState->numEnemiesActive - 1) {
                // Swap with the last active enemy
                gameState->enemies[i] = gameState->enemies[gameState->numEnemiesActive - 1];
            }
            gameState->numEnemiesActive--; // Reduce active count
            continue;
        }

        // Path Movement
        SDL_Point *p = (enemy->side == 0) ? paths->points.left : paths->points.right;
        int pathCount = paths->nmbrOfPoints;

        if (enemy->currentSegment < pathCount - 1) {
            SDL_Point p1 = p[enemy->currentSegment];
            SDL_Point p2 = p[enemy->currentSegment + 1];
            float segDist = distance_between_points((float)p1.x, (float)p1.y, (float)p2.x, (float)p2.y);
            float moveAmount = 0.0f;
            moveAmount = (enemy->speed * dt) / segDist;
            enemy->segmentProgress += moveAmount;


            // Check if moved to the next segment
            if (enemy->segmentProgress >= 1.0f) {
                enemy->currentSegment++;
                // Check if the path ends here
                if (enemy->currentSegment >= pathCount - 1) {
                     enemy->active = false; // Reached the end
                     // Reduce player HP based on side
                     int *hpToReduce = (enemy->side == 0) ? &gameState->leftPlayerHP : &gameState->rightPlayerHP;
                     *hpToReduce -= enemy->hp; // Lose HP equal to enemy's current HP when it reaches the end
                     if (*hpToReduce < 0) *hpToReduce = 0;
                     // Let array compaction handle removal in the next loop iteration
                     continue;
                } else {
                    // Reset progress for the new segment
                    enemy->segmentProgress = 0.0; 
                }
            }

            // Update position and angle based on current segment and progress
            p1 = p[enemy->currentSegment];
            p2 = p[enemy->currentSegment + 1]; // Safe now because we checked segment < count-1

            enemy->x = newCords((float)p1.x, (float)p2.x, enemy->segmentProgress);
            enemy->y = newCords((float)p1.y, (float)p2.y, enemy->segmentProgress);

            // Update angle
            float dx = (float)p2.x - (float)p1.x;
            float dy = (float)p2.y - (float)p1.y;
            enemy->angle = atan2f(dy, dx) * 180.0f / M_PI + 90.0f;
            

        } 
        i++; // Only increment if the enemy wasn't deactivated
    }

     // Check game over condition after updates
    if (!gameState->gameOver && (gameState->leftPlayerHP <= 0 || gameState->rightPlayerHP <= 0)) {
        gameState->gameOver = true;
        gameState->winner = (gameState->leftPlayerHP <= 0) ? 1 : 0; // winner
        printf("GAME OVER Condition Met (Detected in update_enemies).\n");
    }
}


// Spawns a pair of enemies, one on each path
void spawn_enemy_pair(GameState *gameState, GameResources *resources) {
    if (!gameState || !resources || gameState->numEnemiesActive > MAX_ENEMIES - 2) {
        // Check if we can spawn two enemies
        return;
    }
    
    gameState->enemySpawnCounter++; //increase enemySpawnCount before wave check 
    int type = gameState->enemySpawnCounter % 3; // Cycle through types 0, 1, 2
    if (gameState->enemySpawnCounter%NEW_WAVE_BY_ENEMY_SPAWN==0&&gameState->enemySpawnCounter!=0) 
    {
        gameState->inWaveDelay=true;
        gameState->spawnCooldown=WAVE_PAUSE_LENGTH;
        return;
    }
    printf("Wave: %d\n", gameState->currentWave);
    printf("Enemy Spawn Count: %d\n", gameState->enemySpawnCounter);




    int hp = 0, baseHp=0;
    float speed = 300.0f; // Base speed
    SDL_Texture *texture = NULL;

    switch (type){
        case 0: baseHp=1; break;
        case 1: baseHp=3; break;
        case 2: baseHp=5; break;
        default: break;
        }
    
        baseHp=ceil(baseHp* pow(1.5,gameState->currentWave)); //skalar upp hp beroende på currentWave
        hp=baseHp;
    
        //sätter texture av enemy beroende på hp
        if (hp<=1) texture = resources->enemyTextures[0];  
        else if (hp<=3) texture = resources->enemyTextures[1];
        else if (hp>3) texture = resources->enemyTextures[2];
        
    

    // Spawn Left Enemy
    Enemy *left_enemy = &gameState->enemies[gameState->numEnemiesActive++]; // Get slot and increment count
    left_enemy->active = true;
    left_enemy->side = 0;
    left_enemy->type = type;
    left_enemy->hp = hp;
    left_enemy->speed = speed;
    left_enemy->currentSegment = 0;
    left_enemy->segmentProgress = 0.0f;
    left_enemy->x = (float)gameState->paths.points.left[0].x;
    left_enemy->y = (float)gameState->paths.points.left[0].y;
    left_enemy->angle = 0; // Will be updated in update_enemies
    left_enemy->texture = texture;

    // Spawn Right Enemy
    Enemy *right_enemy = &gameState->enemies[gameState->numEnemiesActive++]; // Get slot and increment count
    right_enemy->active = true;
    right_enemy->side = 1;
    right_enemy->type = type;
    right_enemy->hp = hp;
    right_enemy->speed = speed;
    right_enemy->currentSegment = 0;
    right_enemy->segmentProgress = 0.0f;
    right_enemy->x = (float)gameState->paths.points.right[0].x;
    right_enemy->y = (float)gameState->paths.points.right[0].y;
    right_enemy->angle = 0; // Will be updated in update_enemies
    right_enemy->texture = texture;
}