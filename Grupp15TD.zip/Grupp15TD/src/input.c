#include <SDL2/SDL.h>
#include <stdio.h>

#include "engine.h"

// Handles input based on the current game mode/context
// Returns true if quit was requested, false otherwise
// Sets the quit_flag_ptr directly if quit is requested
void handle_input(InputContext context, GameState *gameState, GameResources *resources, ClientInstance *client, bool *quit_flag_ptr) {
    if (!quit_flag_ptr) return;

    SDL_Event event;
    int mouseX, mouseY; SDL_GetMouseState(&mouseX, &mouseY);
    int leftBoundary = (int)(WINDOW_WIDTH * 0.48f); int rightBoundary = (int)(WINDOW_WIDTH * 0.52f);

    while (SDL_PollEvent(&event)) {
        if (event.type == SDL_QUIT) {
            printf("SDL_QUIT event detected!\n"); 
            *quit_flag_ptr = true; // Set the flag
        }
        if (event.type == SDL_KEYDOWN && event.key.keysym.sym == SDLK_ESCAPE) {
            bool wasPlacing = false;
            if (context == INPUT_CONTEXT_SINGLEPLAYER && gameState && gameState->placingBird) {
                gameState->placingBird = false;
                gameState->selectedOption = -1;
                wasPlacing = true;
                printf("Placement cancelled via ESC.\n");
            }
            else if (context == INPUT_CONTEXT_CLIENT && client && client->placingBird) {
                client->placingBird = false;
                client->selectedOption = -1;
                wasPlacing = true;
                printf("Placement cancelled via ESC.\n");
            }
            if (!wasPlacing) {
                printf("ESC pressed - setting quit flag.\n");
                *quit_flag_ptr = true; // Set the flag
            }
        }

        // Context Specific Input Handling
        if (context == INPUT_CONTEXT_MAIN_MENU) { /* Space check handled in main loops */ }
        else if (context == INPUT_CONTEXT_SINGLEPLAYER && gameState && resources) {
             int clickX = event.button.x; int clickY = event.button.y;
            if (event.type == SDL_MOUSEBUTTONDOWN && event.button.button == SDL_BUTTON_LEFT) {
                if (!gameState->placingBird) {
                    for (int i = 0; i < 3; i++) {
                        SDL_Rect ir = resources->towerOptions[i].iconRect;
                        if (clickX >= ir.x && clickX <= ir.x + ir.w && clickY >= ir.y && clickY <= ir.y + ir.h) {
                            if (gameState->money >= resources->towerOptions[i].prototype.cost) {
                                printf("Selected tower type %d for placement.\n", i);
                                gameState->placingBird = true; gameState->selectedOption = i;
                            } else {
                                printf("Cannot afford tower type %d (Cost: %d, Have: %d)\n", i, resources->towerOptions[i].prototype.cost, gameState->money);
                            }
                            break;
                        }
                    }
                } else {
                    if (clickX < leftBoundary || clickX > rightBoundary) {
                        if (gameState->selectedOption != -1) {
                            place_tower(gameState, resources, gameState->selectedOption, clickX, clickY, -1);
                            gameState->placingBird = false;
                            gameState->selectedOption = -1;
                        }
                    } else {
                        printf("Cancelled placement (clicked in middle zone).\n");
                        gameState->placingBird = false;
                        gameState->selectedOption = -1;
                    }
                }
            }
        }
        else if (context == INPUT_CONTEXT_CLIENT && client && resources) {
             int clickX = event.button.x;
             int clickY = event.button.y;
             if (event.type == SDL_MOUSEBUTTONDOWN && event.button.button == SDL_BUTTON_LEFT) {
                 if (!client->placingBird) {
                    for (int i = 0; i < 3; i++) {
                        SDL_Rect ir = resources->towerOptions[i].iconRect;
                        if (clickX >= ir.x && clickX <= ir.x + ir.w && clickY >= ir.y && clickY <= ir.y + ir.h) {
                            printf("Selected tower type %d for placement request.\n", i);
                            client->placingBird = true;
                            client->selectedOption = i;
                            break;
                        }
                    }
                } else {
                     // Check if click is outside the middle UI zone
                     if (clickX < leftBoundary || clickX > rightBoundary) {
                         if (client->selectedOption != -1 && client->playerIndex != -1) {
                             printf("Requesting placement: type %d at (%d, %d) by player %d\n", client->selectedOption, clickX, clickY, client->playerIndex);

#ifdef CLIENT
                             // This block only compiles when CLIENT is defined
                             ClientPacketData pd = {0};
                             pd.command = CLIENT_CMD_PLACE_TOWER;
                             pd.playerIndex = client->playerIndex;
                             pd.towerTypeIndex = client->selectedOption;
                             pd.targetX = clickX;
                             pd.targetY = clickY;
                             send_client_packet(client, &pd);

#endif // CLIENT
                         }
                     } else {
                         printf("Cancelled placement (clicked in middle zone).\n");
                     }
                     // Always exit placement mode after click
                     client->placingBird = false;
                     client->selectedOption = -1;
                  }
             } 
        } 
    } 
}