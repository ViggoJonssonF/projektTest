#include <stdio.h> 
#include <stdbool.h> 
#include "engine.h"

// Handles automatic money gain over time
void handle_money_gain(GameState *gameState, float dt) {
    if (!gameState || gameState->gameOver || dt <= 0) return;

    gameState->moneyTimer += dt;
    if (gameState->moneyTimer >= MONEY_INTERVAL) {
        gameState->moneyTimer -= MONEY_INTERVAL; 
        gameState->money += MONEY_GAIN;
    }
}