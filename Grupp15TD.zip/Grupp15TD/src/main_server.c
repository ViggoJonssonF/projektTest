#include <stdio.h>
#include <SDL2/SDL.h>

#include "engine.h" // For run_server prototype

#ifdef SERVER
int main(int argc, char *argv[]) {
    (void)argc; (void)argv;
    printf("Starting Tower Defense Server...\n");
    // Server init/cleanup handled within run_server()
    int result = run_server();
    printf("Server process finished with exit code %d.\n", result);
    return result;
}
#endif // SERVER
// Note: Server doesn't render the main menu itself usually,
// but if the debug view needed it, it would pass MODE_SERVER.
