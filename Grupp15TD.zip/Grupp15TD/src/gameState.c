#include <string.h> 
#include <stdio.h>
#include "engine.h" 

// Initialiserar GameState till standardvärden
void initialize_game_state(GameState *gameState, GameResources *resources) {
    if (!gameState || !resources) return;
    memset(gameState, 0, sizeof(GameState));
    gameState->money = START_MONEY;
    gameState->moneyTimer = 0.0f;
    gameState->leftPlayerHP = PLAYER_START_HP;
    gameState->rightPlayerHP = PLAYER_START_HP;
    gameState->spawnTimer = 0.0f;
    gameState->enemySpawnCounter = 0;
    gameState->numEnemiesActive = 0;
    gameState->numPlacedBirds = 0;
    gameState->numProjectiles = 0;
    gameState->placingBird = false;
    gameState->selectedOption = -1;
    gameState->gameOver = false;
    gameState->winner = -1;
    gameState->currentWave = 0;
    gameState->inWaveDelay = true;
    gameState->spawnCooldown = 0.0f;
    gameState->paths = createPaths();

    printf("Game state initialized.\n");
}
